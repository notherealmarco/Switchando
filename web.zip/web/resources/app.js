document.body.requestFullscreen();
$(document).foundation()
